create table ngay_ban_3NF(
    ngay_ban_ID int IDENTITY(1,1) primary key, 
    ngay_ban date
)