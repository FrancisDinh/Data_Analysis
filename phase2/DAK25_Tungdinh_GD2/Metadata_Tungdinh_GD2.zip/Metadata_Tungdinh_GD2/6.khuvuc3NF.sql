insert into khu_vuc_3NF (khu_vuc)
select distinct khu_vuc from du_lieu_ban_hang_backup