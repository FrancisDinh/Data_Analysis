create table khu_vuc_3NF(
    khu_vuc_ID int IDENTITY(1,1) primary key,
    khu_vuc nvarchar(100)
)