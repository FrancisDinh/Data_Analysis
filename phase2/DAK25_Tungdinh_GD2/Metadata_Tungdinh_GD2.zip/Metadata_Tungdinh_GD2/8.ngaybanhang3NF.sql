insert into ngay_ban_3NF(ngay_ban)
select distinct ngay_ban from du_lieu_ban_hang_backup